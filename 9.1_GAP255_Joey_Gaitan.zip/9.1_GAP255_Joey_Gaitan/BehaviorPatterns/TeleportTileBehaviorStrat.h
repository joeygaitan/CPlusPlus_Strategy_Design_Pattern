#pragma once
#include "BehaviorStrategy.h"
class TeleportTileBehaviorStrat :
    public BehaviorStrategy
{
public:
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer) override;
};

