// World.cpp
#include "World.h"
#include "Tile.h"
#include "Player.h"

#include "FloorTile.h"
#include "TreasureTile.h"
#include "BombTile.h"
#include "MimicTile.h"
#include "EndTile.h"

#include "BehaviorStrategy.h"
#include "BombTileBehaviorStrat.h"
#include "EndTileBehaviorStrat.h"
#include "FloorTileBehaviorStrat.h"
#include "TreasureTileBehaviorStrat.h"
#include "MimicTileBehaviorStrat.h"

#include <iostream>
#include <assert.h>

using std::cout;
using std::endl;


World::World()
    : m_grid(0,0)
	, m_pPlayer(nullptr)
    , m_gameOver(false)
{}

World::~World()
{
    delete m_pPlayer;
    m_pPlayer = nullptr;
}

void World::Init(int width, int height)
{
    m_grid.IntializeGrid(width, height);
}

void World::CreatePlayer(int x, int y)
{
    const auto [kWidth, kHeigth] = m_grid.GetWidthHeight();
	assert(x >= 0 && x < kWidth);
	assert(y >= 0 && y < kHeigth);
	m_pPlayer = new Player(x, y);
}

void World::GenerateWorld()
{
    m_grid.GenerateGrid();
}

void World::Draw()
{
    auto [width, heigth] = m_grid.GetWidthHeight();
    system("cls");

    m_pPlayer->DrawUi();

	for (int y = 0; y < width; ++y)
	{
		for (int x = 0; x < heigth; ++x)
		{
			if (m_pPlayer && m_pPlayer->GetX() == x && m_pPlayer->GetY() == y)
			{
				m_pPlayer->Draw();
			}
			else
			{
				int index = (y * width) + x;
                std::cout << "Index: " << index;
                system("pause");
                m_grid.DisplayTile(index);
			}
		}
		cout << endl;
	}
}

void World::Update()
{
    auto [width, heigth] = m_grid.GetWidthHeight();

    if (!m_pPlayer->Update(&m_grid))
    {
        m_pPlayer->Kill();  // ending the game prematurely does not result in a win
        EndGame();
        return;
    }

    int x = m_pPlayer->GetX();
    int y = m_pPlayer->GetY();

    // this is a death arena, so check to see if we went over the edge of the world
    if (x < 0 || y < 0 || x >= width || y >= heigth)
    {
        m_pPlayer->Kill();
        EndGame();
        return;
    }

    // process the tile the player is on
    int index = (y * width) + x;
    m_grid.GetTileByIndex(index)->OnEnter(m_pPlayer);
}

void World::EndGame()
{
    if (!m_pPlayer->IsDead())
    {
        cout << "\n\nYou won!\n\n";
        cout << "Your final score is: " << m_pPlayer->CalculateScore() << "\n";
    }
    else
    {
        cout << "\n\nYou have died.\n\n";
    }

    m_gameOver = true;
}
