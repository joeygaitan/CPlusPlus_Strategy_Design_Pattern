#include "TeleportTileBehaviorStrat.h"

void TeleportTileBehaviorStrat::ExcecuteStrategy(Tile* pTile, Player* pPlayer)
{

}