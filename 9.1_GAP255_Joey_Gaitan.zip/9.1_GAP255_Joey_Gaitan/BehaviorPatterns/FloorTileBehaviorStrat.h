#pragma once
#include "BehaviorStrategy.h"

class FloorTileBehaviorStrat :
    public BehaviorStrategy
{
public:
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer) override { };
};

