// World.h
#ifndef __WORLD_H__
#define __WORLD_H__

#include <utility>
#include "Grid.h"

class Tile;
class Player;

class World
{
	Player* m_pPlayer;
    bool m_gameOver;
    Grid m_grid;

public:
	World();
	~World();

	// initialization
	void Init(int width, int height);
	void CreatePlayer(int x = 0, int y = 0);
	void GenerateWorld();

	// update
	void Draw();
	void Update();

    // end
    void EndGame();
    bool IsGameOver() const { return m_gameOver; }
};

#endif
