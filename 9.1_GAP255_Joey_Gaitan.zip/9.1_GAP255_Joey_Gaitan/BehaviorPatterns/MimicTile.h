// MimicTile.h
#ifndef __MIMICTILE_H__
#define __MIMICTILE_H__

#include "Tile.h"
#include "BehaviorStrategy.h"
#include <utility>

class MimicTile : public Tile
{
public:
    typedef std::pair<int, int> DamageRange;

    enum class State
    {
        k_hidden,
        k_revealed,
        k_exploded,
    };

    static const DamageRange s_damageRange;
private:
    State m_state;
public:
    MimicTile(BehaviorStrategy* pBehavior);

    ~MimicTile() { delete m_pBehaviorStrategy; }

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
    const State& GetState() const { return m_state; }
    void SetState(State newState) { m_state = newState; }
};

#endif

