#pragma once
#include "Tile.h"
#include <vector>
#include <iostream>

class Grid
{
    enum class TileType
    {
        k_floor,
        k_bomb,
        k_treasure,
        k_mimic,
        k_numTiles,
    };

    typedef std::pair<int, TileType> TileProbability;

    static inline const TileProbability s_tileProbabilities[(int)TileType::k_numTiles] = {
        TileProbability(800, TileType::k_floor),
        TileProbability(75, TileType::k_bomb),
        TileProbability(75, TileType::k_treasure),
        TileProbability(50, TileType::k_mimic),
    };

    int m_width;
    int m_height;

    Tile** m_ppGrid;
public:

    Grid(int width, int height);

    ~Grid();

    // Intializes Grid and sets up size.
    void IntializeGrid(int width, int height);

    // Generates the grid and fills it with objects.
    void GenerateGrid();

    void DisplayTile(int index);

    // Gets a tile using x and y locations.
    Tile* GetTile(int x, int y);

    // Gets a tile by index.
    Tile* GetTileByIndex(int index);

    // Gets the height and width of the Grid.
    std::pair<int, int> GetWidthHeight() const { return { m_width, m_height }; }

    // Gets a const tile from the grid to display.
    const Tile* const GetConstTile(int x, int y);

    // Sets a tile for the grid.
    void SetTile(int index, Tile* pTile);
};

