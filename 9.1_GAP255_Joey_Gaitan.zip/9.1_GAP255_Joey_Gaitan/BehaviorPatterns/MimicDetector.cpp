#include "MimicDetector.h"
#include "Player.h"

void MimicDetector::MimicDetection(Grid* pGrid, Player* pPlayer)
{
    if (s_mimicViewAmount > 0)
    {
        for (auto& [intX, intY] : s_playerExteriorPositions)
        {
            std::pair<int, int> newXY = MakeXY(pPlayer->GetX(), pPlayer->GetY(), intX, intY);
            Tile* pTile = GetTile(pGrid, newXY.first, newXY.second);
            MimicCheck(pTile);
        }
    }
    else
    {
        std::cout << "Ran out of mimic detection spells :/" << "\n";
        return;
    }

    --s_mimicViewAmount;
}

std::pair<int, int> MimicDetector::MakeXY(int playerX, int playerY, int newAdditionX, int newAdditionY)
{
    playerX += newAdditionX;
    playerY += newAdditionY;

    return { playerX, playerY };
}

void MimicDetector::MimicCheck(Tile* pTile)
{
    if (pTile != nullptr)
    {
        if (pTile->GetTile() == Tile::TileType::kMimic)
        {
            MimicTile* pMimicTile = dynamic_cast<MimicTile*>(pTile);

            pMimicTile->SetState(MimicTile::State::k_revealed);
        }
        else
        {
            return;
        }
    }
    else
    {
        return;
    }
}

Tile* MimicDetector::GetTile(Grid* pGrid, int x, int y)
{
    const auto [kWidth, kHeigth] = pGrid->GetWidthHeight();

    if (x < 0 || y < 0 || x >= kWidth || y >= kHeigth)
    {
        return nullptr;
    }

    int index = (y * kWidth) + x;
    return pGrid->GetTileByIndex(index);
}
