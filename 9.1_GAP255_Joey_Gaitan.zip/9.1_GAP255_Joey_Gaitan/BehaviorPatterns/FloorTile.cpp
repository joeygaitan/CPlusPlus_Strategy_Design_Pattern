// FloorTile.cpp
#include "FloorTile.h"
#include <iostream>

using std::cout;

FloorTile::FloorTile(BehaviorStrategy* pBehavior)
	: Tile(pBehavior, Tile::TileType::kFloor)
{}

void FloorTile::Draw()
{
	cout << ".";
}
