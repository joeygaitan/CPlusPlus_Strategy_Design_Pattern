// EndTile.cpp
#include "EndTile.h"
#include "World.h"
#include <iostream>

EndTile::EndTile(BehaviorStrategy* pBehavior)
    : Tile(pBehavior, Tile::TileType::kEnd)
{}

void EndTile::Draw()
{
    std::cout << "H";
}

void EndTile::OnEnter(Player* pPlayer)
{
    m_pBehaviorStrategy->ExcecuteStrategy(this, pPlayer);
}
