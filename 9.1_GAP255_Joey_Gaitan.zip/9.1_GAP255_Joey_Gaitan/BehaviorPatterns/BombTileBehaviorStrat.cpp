#include "BombTileBehaviorStrat.h"

void BombTileBehaviorStrat::ExcecuteStrategy(Tile* pTile, Player* pPlayer)
{
    BombTile* pBombTile = reinterpret_cast<BombTile*>(pTile);

    if (pBombTile->GetState() == BombTile::State::k_active)
    {
        int damage = (rand() % (BombTile::s_damageRange.second - BombTile::s_damageRange.first)) + BombTile::s_damageRange.first;
        pPlayer->Damage(damage);
        pBombTile->SetState(BombTile::State::k_dead);
    }
}
