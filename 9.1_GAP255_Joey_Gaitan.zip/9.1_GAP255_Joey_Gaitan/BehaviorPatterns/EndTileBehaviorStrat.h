#pragma once
#include "BehaviorStrategy.h"
#include "World.h"

class EndTileBehaviorStrat :
    public BehaviorStrategy
{
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer) override;
};

