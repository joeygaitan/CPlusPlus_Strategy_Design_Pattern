#include "EndTileBehaviorStrat.h"

extern World* g_pWorld;  // let's us access a global variable declared in another CPP

void EndTileBehaviorStrat::ExcecuteStrategy(Tile* pTile, Player* pPlayer)
{
    g_pWorld->EndGame();
}
