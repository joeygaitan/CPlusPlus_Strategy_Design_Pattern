#include "TeleportTile.h"

TeleportTile::TeleportTile(BehaviorStrategy* pBehavior, Tile* pOtheTile)
    : Tile(pBehavior, Tile::TileType::kTeleporter)
    , m_pOtherTile(pOtheTile)
{}

void TeleportTile::Draw()
{
    std::cout << "O";
}

void TeleportTile::OnEnter(Player* pPlayer)
{

}
