// BombTile.h
#ifndef __BOMBTILE_H__
#define __BOMBTILE_H__

#include "Tile.h"
#include "BehaviorStrategy.h"
#include <utility>

class BombTile : public Tile
{
public:
    typedef std::pair<int, int> DamageRange;

    enum class State
    {
        k_active,
        k_dead,
    };

    static const DamageRange s_damageRange;

private:
    State m_state;
public:
    ~BombTile() { delete m_pBehaviorStrategy; }

    BombTile(BehaviorStrategy* pBehavior);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;

    const State& GetState() { return m_state; } 
    void SetState(State newState) { m_state = newState; }
};

#endif

