#pragma once
#include "Tile.h"
#include "MimicTile.h"
#include "Grid.h"

class Player;

#include <iostream>
#include <map>

class MimicDetector
{
private:
    using IntMap = std::map<const int, const int>;

    // All possible units
    static inline IntMap s_playerExteriorPositions = {
        {-1, -1}
        , {0, -1}
        , {1, -1}
        , {-1, 0}
        , {1, 0}
        , {-1, 0}
        , {1, 1}
    };
public:
    MimicDetector() {};

    static inline int s_mimicViewAmount = 3;

    // makes the updated x and y coords to test for in scope or not later.
    std::pair<int, int> MakeXY(int playerX, int playerY, int newAdditionX, int newAdditionY);
    
    // Checks each possibility of locations of the player.
    void MimicDetection(Grid* pGrid, Player* pPlayer);

    // Checks if the tile is Mimic tile if not it returns.
    void MimicCheck(Tile* pTile);

    // Gets the specified tile of choice.
    Tile* GetTile(Grid* pGrid, int x, int y);
};

