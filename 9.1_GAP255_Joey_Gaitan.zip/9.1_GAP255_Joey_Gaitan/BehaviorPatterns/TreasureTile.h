// TreasureTile.h
#ifndef __TREASURETILE_H__
#define __TREASURETILE_H__

#include "Tile.h"
#include "BehaviorStrategy.h"
#include <utility>

class TreasureTile : public Tile
{
public:
    typedef std::pair<int, int> TreasureRange;

    static const TreasureRange s_treasureRange;
private:
    int m_amount;
    bool m_collected;
public:
    TreasureTile(BehaviorStrategy* pBehavior);

    ~TreasureTile() { delete m_pBehaviorStrategy; }

    void Draw() override;
    void OnEnter(Player* pPlayer) override;

    const int& GetAmount() const { return m_amount; }
    const bool& GetCollected() const { return m_collected; }

    void SetCollected(bool newCondition) { m_collected = newCondition; }
};

#endif
