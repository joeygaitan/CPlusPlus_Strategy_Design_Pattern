#pragma once
#include "BehaviorStrategy.h"
#include "BombTile.h"
#include "Player.h"

class BombTileBehaviorStrat :
    public BehaviorStrategy
{
public:
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer) override;
};

