// Tile.h
#pragma once

class Player;
struct BehaviorStrategy;

class Tile
{
public:
	enum class TileType
	{
		kBomb,
		kEnd,
		kFloor,
		kMimic,
		kTreasure,
		kTeleporter
	};
protected: 
	BehaviorStrategy* m_pBehaviorStrategy;
	TileType m_tileType;
public:
	Tile(BehaviorStrategy* pBehavior, TileType type)
		: m_pBehaviorStrategy(pBehavior)
		, m_tileType(type)
	{};

    virtual ~Tile() { }  // if your class is being used as a base class, it's best to have a virtual destructor
	virtual void Draw() = 0;

	// Does some kind of modification to the players member variables and possibly games win state.
	virtual void OnEnter(Player* pPlayer) { }

	void SetTile(TileType newTile) { m_tileType = newTile; }
	const TileType& GetTile() const { return m_tileType; }
};

