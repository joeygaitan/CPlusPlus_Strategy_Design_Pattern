#include "Grid.h"

#include "FloorTile.h"
#include "TreasureTile.h"
#include "BombTile.h"
#include "MimicTile.h"
#include "EndTile.h"

#include "BehaviorStrategy.h"
#include "BombTileBehaviorStrat.h"
#include "EndTileBehaviorStrat.h"
#include "FloorTileBehaviorStrat.h"
#include "TreasureTileBehaviorStrat.h"
#include "MimicTileBehaviorStrat.h"

#include <assert.h>

Grid::Grid(int width, int height)
    : m_width(width)
    , m_height(height)
    , m_ppGrid(nullptr)
{}

Grid::~Grid()
{
    for (int i = 0; i < m_width * m_height; ++i)
    {
        delete m_ppGrid[i];
    }
    
    delete[] m_ppGrid;
    m_ppGrid = nullptr;
}

Tile* Grid::GetTile(int x, int y)
{
    int index = (y * m_width) + x;
    return m_ppGrid[index];
}

Tile* Grid::GetTileByIndex(int index)
{
    return m_ppGrid[index];
}

const Tile* const Grid::GetConstTile(int x, int y)
{
    int index = (y * m_width) + x;
    return m_ppGrid[index];
}

void Grid::IntializeGrid(int width, int height)
{
    // if we have a grid, destroy it
    if (m_ppGrid)
    {
        for (int i = 0; i < m_width * m_height; ++i)
        {
            delete m_ppGrid[i];
        }
        delete[] m_ppGrid;
        m_ppGrid = nullptr;
    }

    // create and fill the grid with nothing
    m_ppGrid = new Tile*[m_width * m_height];
    for (int i = 0; i < m_width * m_height; ++i)
    {
        m_ppGrid[i] = nullptr;
    }

    m_width = width;
    m_height = height;
}

void Grid::GenerateGrid()
{
    // calculate the max probability
    int maxProbability = 0;
    for (int i = 0; i < (int)TileType::k_numTiles; ++i)
    {
        maxProbability += s_tileProbabilities[i].first;
    }

    // create the start and end tiles
    int lastIndex = (m_width * m_height) - 1;
    // special tile for ending the level; there is only one of these
    m_ppGrid[lastIndex] = new EndTile(new EndTileBehaviorStrat);
    std::cout << "here after set tile Set last tile..." << "\n";
    // guarantee that the starting location is open
    m_ppGrid[0] = new FloorTile(new FloorTileBehaviorStrat);
    std::cout << "here after set tile 0..." << "\n";

    // guarantee at least one mimic. Skips the first place but makes sure you dont go the length.
    int randomTile = (rand() % (lastIndex - 1)) + 1;
    assert(GetTileByIndex(randomTile) == nullptr);  // if this fires, it means our math is wrong
    m_ppGrid[randomTile] = new MimicTile(new MimicTileBehaviorStrat);

    // populate the rest of the world
    for (int tileIndex = 1; tileIndex < (m_width * m_height) - 1; ++tileIndex)
    {
        // skip this tile if we've already set it
        if (GetTileByIndex(tileIndex) != nullptr)
            continue;

        int roll = rand() % maxProbability;
        int probabilityIndex = 0;
        while (true)
        {
            roll -= s_tileProbabilities[probabilityIndex].first;
            if (roll < 0)
                break;
            ++probabilityIndex;
        }

        assert(probabilityIndex >= 0 && probabilityIndex < (int)TileType::k_numTiles);

        switch (s_tileProbabilities[probabilityIndex].second)
        {
        case TileType::k_floor:
            m_ppGrid[tileIndex] = new FloorTile(new FloorTileBehaviorStrat);
            break;

        case TileType::k_bomb:
            m_ppGrid[tileIndex] = new BombTile(new BombTileBehaviorStrat);
            break;

        case TileType::k_treasure:
            // m_ppGrid[tileIndex] = new FloorTile(new FloorTileBehaviorStrat);
            m_ppGrid[tileIndex] = new TreasureTile(new TreasureTileBehaviorStrat);
            break;

        case TileType::k_mimic:
            // m_ppGrid[tileIndex] = new FloorTile(new FloorTileBehaviorStrat);
            m_ppGrid[tileIndex] = new MimicTile(new MimicTileBehaviorStrat);
            break;

        default:
            std::cout << "ERROR: Invalid type type." << "\n";
            break;
        }
    }
}

void Grid::DisplayTile(int index)
{
    GetTileByIndex(index)->Draw();
}

void Grid::SetTile(int index, Tile* pTile)
{
    m_ppGrid[index] = pTile;
}