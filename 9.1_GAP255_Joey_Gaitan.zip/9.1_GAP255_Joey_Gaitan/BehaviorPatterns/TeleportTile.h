#pragma once
#include "Tile.h"

#include <iostream>

class TeleportTile :
    public Tile
{
private:
    Tile* m_pOtherTile;
public:
    TeleportTile(BehaviorStrategy* pBehavior, Tile* pOtheTile);

    ~TeleportTile() { delete m_pOtherTile; }

    void Draw() override;
    void OnEnter(Player* pPlayer);
};

