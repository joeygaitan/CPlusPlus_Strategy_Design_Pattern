#pragma once
#include "BehaviorStrategy.h"
#include "MimicTile.h"
#include "Player.h"

class MimicTileBehaviorStrat :
    public BehaviorStrategy
{
public:
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer) override;
};

