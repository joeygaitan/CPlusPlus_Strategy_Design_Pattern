// EndTile.h
#ifndef __ENDTILE_H__
#define __ENDTILE_H__

#include "Tile.h"
#include "BehaviorStrategy.h"

class EndTile : public Tile
{
public:
    EndTile(BehaviorStrategy* pBehavior);

    ~EndTile() { delete m_pBehaviorStrategy; }

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};

#endif

