#pragma once
#include "Tile.h"

struct BehaviorStrategy
{
    // Executes the strategy of the current strategy pattern.
    virtual void ExcecuteStrategy(Tile* pTile, Player* pPlayer) = 0;

    virtual ~BehaviorStrategy() {};
};

