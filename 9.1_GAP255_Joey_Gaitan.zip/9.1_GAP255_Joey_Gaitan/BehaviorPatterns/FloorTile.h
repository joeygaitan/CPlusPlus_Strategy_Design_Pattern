// FloorTile.h
#ifndef __FLOORTILE_H__
#define __FLOORTILE_H__

#include "Tile.h"
#include "BehaviorStrategy.h"

class FloorTile : public Tile
{
public:
	FloorTile(BehaviorStrategy* pBehavior);

	~FloorTile() { delete m_pBehaviorStrategy; }

	void Draw() override;
};

#endif
