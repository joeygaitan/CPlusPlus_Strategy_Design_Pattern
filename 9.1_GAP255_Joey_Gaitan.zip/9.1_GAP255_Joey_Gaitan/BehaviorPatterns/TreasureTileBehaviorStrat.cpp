#include "TreasureTileBehaviorStrat.h"

void TreasureTileBehaviorStrat::ExcecuteStrategy(Tile* pTile, Player* pPlayer)
{
    TreasureTile* pTreasureTile = dynamic_cast<TreasureTile*>(pTile);

    if (!pTreasureTile->GetCollected())
    {
        pPlayer->AddGold(pTreasureTile->GetAmount());
        pTreasureTile->SetCollected(true);
    }
}
