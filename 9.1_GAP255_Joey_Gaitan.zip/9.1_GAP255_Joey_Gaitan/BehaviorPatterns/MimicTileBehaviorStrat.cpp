#include "MimicTileBehaviorStrat.h"

void MimicTileBehaviorStrat::ExcecuteStrategy(Tile* pTile, Player* pPlayer)
{
    MimicTile* pMimicTile = dynamic_cast<MimicTile*>(pTile);

    if (pMimicTile->GetState() == MimicTile::State::k_hidden || pMimicTile->GetState() == MimicTile::State::k_revealed)
    {
        int damage = (rand() % (MimicTile::s_damageRange.second - MimicTile::s_damageRange.first)) + MimicTile::s_damageRange.first;
        pPlayer->Damage(damage);
        pMimicTile->SetState(MimicTile::State::k_exploded);
    }
}