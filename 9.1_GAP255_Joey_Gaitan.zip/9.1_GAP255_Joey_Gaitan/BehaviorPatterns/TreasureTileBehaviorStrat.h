#pragma once
#include "BehaviorStrategy.h"
#include "Player.h"
#include "TreasureTile.h"

class TreasureTileBehaviorStrat :
    public BehaviorStrategy
{
public:
    void ExcecuteStrategy(Tile* pTile, Player* pPlayer);
};

